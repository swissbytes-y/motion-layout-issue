package ch.swissbytes.syscomappprint.zebra;

/**
 * Created by Jorge on 04/11/2015.
 */
public class ZebraFontFactory {

    public static ZebraFont getZebraFont(ZebraFontType fontType) {
        switch (fontType) {
            case HEADER_TITLE_FONT:
                return new HeaderTitleFont();
            case TITLE_FONT:
                return new TitleFont();
            case CONTENT_FONT:
                return new ContentFont();
            default:
                throw new IllegalArgumentException("font type not exists");
        }
    }
}
