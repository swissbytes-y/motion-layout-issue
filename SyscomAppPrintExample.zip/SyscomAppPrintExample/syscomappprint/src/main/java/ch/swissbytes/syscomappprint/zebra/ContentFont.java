package ch.swissbytes.syscomappprint.zebra;

/**
 * Created by Jorge on 04/11/2015.
 */
public class ContentFont implements ZebraFont {

    @Override
    public int getNumber() {
        return 7;
    }

    @Override
    public int getSize() {
        return 0;
    }

    @Override
    public double getWidth() {
        return 1.5;
    }

    @Override
    public double getHeight() {
        return 24;
    }

}
