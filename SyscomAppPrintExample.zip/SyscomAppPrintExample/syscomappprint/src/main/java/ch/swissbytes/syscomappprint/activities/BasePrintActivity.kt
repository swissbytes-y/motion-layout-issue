package ch.swissbytes.syscomappprint.activities

import android.os.Bundle
import android.view.MenuItem
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.databinding.library.baseAdapters.BR
import ch.swissbytes.syscomappprint.R
import ch.swissbytes.syscomappprint.activities.viewmodels.PrintBaseVModel
import ch.swissbytes.syscomappprint.utils.SysPrinterInterface
import kotlinx.android.synthetic.main.activity_print.view.*

abstract class BasePrintActivity : AppCompatActivity() {

    lateinit var vm: PrintBaseVModel
    lateinit var toolbar: Toolbar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ViewDataBinding>(this, R.layout.activity_print)
        vm = PrintBaseVModel(this){ onStartPrinting(it) }
        binding.setVariable(BR.vm, vm)

//        setSupportActionBar(binding.root.toolbar)
//        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar = binding.root.toolbar
        setUpActionBar()
    }

    private fun setUpActionBar(){
        setSupportActionBar(toolbar)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    fun setNavigationIcon(@DrawableRes res: Int){
        toolbar.setNavigationIcon(res)
    }

    fun setTitle(text: String){
        toolbar.title = "TEST"
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId){ android.R.id.home -> finish() }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        vm.onDestroy()
    }

    abstract fun onStartPrinting(printer: SysPrinterInterface)
}
