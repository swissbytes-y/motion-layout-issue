package ch.swissbytes.syscomappprint.zebra;

/**
 * Created by Jorge on 04/11/2015.
 */
public enum ZebraFontType {

    HEADER_TITLE_FONT, TITLE_FONT, CONTENT_FONT
}
