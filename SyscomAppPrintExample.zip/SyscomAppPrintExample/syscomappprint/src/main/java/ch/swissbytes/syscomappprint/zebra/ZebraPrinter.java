package ch.swissbytes.syscomappprint.zebra;

import android.graphics.Bitmap;
import android.os.Looper;
import com.zebra.sdk.comm.BluetoothConnection;
import com.zebra.sdk.comm.Connection;
import com.zebra.sdk.comm.ConnectionException;
import com.zebra.sdk.graphics.internal.ZebraImageAndroid;
import com.zebra.sdk.printer.PrinterLanguage;
import com.zebra.sdk.printer.ZebraPrinterFactory;
import com.zebra.sdk.printer.ZebraPrinterLanguageUnknownException;

import java.io.UnsupportedEncodingException;

/**
 * Created by Jorge on 04/11/2015.
 */
public class ZebraPrinter {

    /**
     * Size of the printer page in mm
     */
    public static final double PAGE_WIDTH = 76.2;
    /**
     * Dots per mm
     */
    public static final double DPM = 8;

    /**
     * Width of the page margin in mm
     */
    public static final double PAGE_MARGIN = 4.4;

    private StringBuilder builder;
    private ZebraFont font;
    private String macAddress;
    private Connection printerConnection;

    /**
     * Contains functions to interact with the printer
     *
     * @param macAddress Mac address of the printer
     */
    public ZebraPrinter(String macAddress) {
        builder = new StringBuilder();
        this.font = ZebraFontFactory.getZebraFont(ZebraFontType.CONTENT_FONT);
        this.macAddress = macAddress;
    }

    /**
     * Contains functions to interact with the printer
     *
     * @param macAddress Mac address of the printer
     * @param font       ZebraFont instance for printing
     */
    public ZebraPrinter(String macAddress, ZebraFont font) {
        builder = new StringBuilder();
        this.font = font;
        this.macAddress = macAddress;
    }

    /**
     * Set the printer font
     *
     * @param font Class tha implement the ZebraFont interface
     */
    public void setFont(ZebraFont font) {
        builder.append("! U1 SETLP ")
                .append(font.getNumber())
                .append(" ")
                .append(font.getSize())
                .append(" ")
                .append(font.getHeight())
                .append("\r\n");
        this.font = font;
    }

    public void printQrCode(String value){
        try {
            printerConnection.write((value+"\r\n").getBytes());
        } catch (ConnectionException e){}
    }



    /**
     * Change the position of the print head to the specified x position
     *
     * @param x Value in dots. 8 dots = 1mm
     */
    public void setX(double x) {
        builder.append("! U1 X ")
                .append(x)
                .append("\r\n");
    }

    /**
     * Change the position of the print head to the specified y position
     *
     * @param y Value in dots. 8 dots = 1mm
     */
    public void setY(double y) {
        builder.append("! U1 Y ")
                .append(y)
                .append("\r\n");
    }

    /**
     * Change the position of the print head to the specified x and y position
     *
     * @param x Value in dots. 8 dots = 1mm
     * @param y Value in dots. 8 dots = 1mm
     */
    public void setXY(double x, double y) {
        builder.append("! U1 XY ")
                .append(x)
                .append(" ")
                .append(y)
                .append("\r\n");
    }

    /**
     * Change the position of the print head relative to his current position in x
     *
     * @param x Value in dots. 8 dots = 1mm
     */
    public void setRX(double x) {
        builder.append("! U1 RX ")
                .append(x)
                .append("\r\n");
    }

    /**
     * Change the position of the print head relative to his current position in y
     *
     * @param y Value in dots. 8 dots = 1mm
     */
    public void setRY(double y) {
        builder.append("! U1 RY ")
                .append(y)
                .append("\r\n");
    }

    /**
     * Change the position of the print head relative to his current position in x and y
     *
     * @param x Value in dots. 8 dots = 1mm
     * @param y Value in dots. 8 dots = 1mm
     */
    public void setRXY(double x, double y) {
        builder.append("! U1 RX ")
                .append(x)
                .append(" ")
                .append(y)
                .append("\r\n");
    }

    /**
     * Set Bold to the current font.
     *
     * @param offset value between 0 and 5 that indicates how Bold must be the text. 0 removes Bold from the font
     */
    public void setBold(int offset) {
        builder.append("! U1 SETBOLD ")
                .append(offset)
                .append("\r\n");
    }

    /**
     * Write the specified text in the current position of the print head
     *
     * @param text Text to write
     */
    public void write(String text) {
        builder.append(text);
    }

    /**
     * Write the specified text and then move the print head to the next line
     *
     * @param text Text to write
     */
    public void writeAndGoToNextLine(String text) {
        builder.append(text)
                .append("\r\n");
    }

    /**
     * Write the specified text center in the page and then move the print head to the next line.
     *
     * @param text   Text to write
     * @param center True if the text must be center or False if not
     */
    public void writeAndGoToNextLine(String text, boolean center) {
        if (center) {
            center(text);
        }
        writeAndGoToNextLine(text);
    }

    /**
     * Move the print head to the next line of the page
     */
    public void goToTheNextLine() {
        builder.append("\r\n");
    }

    /**
     * Center a text in the page
     *
     * @param text Text to center
     */
    private void center(String text) {
        double textLength = text.length() * font.getWidth();
        double posX = ((((PAGE_WIDTH - PAGE_MARGIN) / 2) - (textLength / 2)) * DPM);
        setRX(posX);
    }

    /**
     * Creates and open a connection to the printer
     *
     * @throws ConnectionException
     */
    public void open() throws ConnectionException {
        try {
            Looper.prepare();
        } catch (Exception e) {
            Looper.myLooper().quit();
        }


        printerConnection = new BluetoothConnection(macAddress);
        printerConnection.setMaxTimeoutForRead(2000);
        printerConnection.open();
    }

    /**
     * Close the connection with the printer
     *
     * @throws ConnectionException
     */
    public void close() throws ConnectionException {
        if (isConnected()) {
            printerConnection.close();
        }
//        Looper.myLooper().quit();
    }

    public boolean isConnected(){
        return printerConnection != null && printerConnection.isConnected();
    }

    /**
     * Send the data to print to the printer
     *
     * @throws ConnectionException
     * @throws InterruptedException
     * @throws UnsupportedEncodingException
     */
    public void print() throws ConnectionException,
            InterruptedException, UnsupportedEncodingException {

        String lpData = builder.toString();
        printerConnection.write(lpData.getBytes("ISO-8859-1"));

        Thread.sleep(500);

        builder.setLength(0);

    }


    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public ZebraFont getFont() {
        return font;
    }

    /**
     * Set the feed length after printing
     *
     * @param value Value in dots. 8 dots = 1 mm
     */
    public void setMediaFeedLength(int value) {

        builder.append("! U1 setvar \"media.feed_length\" ")
                .append("\"")
                .append(value)
                .append("\"")
                .append("\r\n");

    }

    /**
     * Prints an image as monochrome image
     *
     * @param image  the image to be printed
     * @param x      horizontal starting position in dots
     * @param y      vertical starting position in dots
     * @param width  desired width of the printed image. Passing a value less than 1 will preserve original width.
     * @param height desired height of the printed image. Passing a value less than 1 will preserve original width.
     * @throws ConnectionException
     * @throws ZebraPrinterLanguageUnknownException
     */
    public void printImage(Bitmap image, int x, int y, int width, int height) throws ConnectionException, ZebraPrinterLanguageUnknownException {
        com.zebra.sdk.printer.ZebraPrinter zebraPrinter = ZebraPrinterFactory.getInstance(PrinterLanguage.CPCL, printerConnection);
        zebraPrinter.printImage(new ZebraImageAndroid(image), x, y, width, height, false); }

    /**
     * Prints a line
     *
     * @param x0    X-coordinate of the top-left corner
     * @param y0    Y-coordinate of the top-left corner
     * @param x1    X-coordinate of:
     *              <p> - top right corner for horizontal</p>
     *              <p> - bottom left corner for vertical</p>
     * @param y1    Y-coordinate of:
     *              <p> - top right corner for horizontal</p>
     *              <p> - bottom left corner for vertical</p>
     * @param width Unit-width (or thickness) of the line
     */
    public void printLine(int x0, int y0, int x1, int y1, int width) {

        builder.append("! 0 200 200 10 1")
                .append("\r\n")
                .append("LINE ").append(x0).append(" ").append(y0).append(" ").append(x1).append(" ").append(y1).append(" ").append(width)
                .append("\r\n")
                .append("FORM")
                .append("\r\n")
                .append("PRINT")
                .append("\r\n");

    }

}
