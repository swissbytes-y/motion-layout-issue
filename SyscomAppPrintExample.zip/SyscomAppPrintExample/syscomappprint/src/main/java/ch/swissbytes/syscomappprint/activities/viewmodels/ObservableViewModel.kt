package ch.swissbytes.syscomappprint.activities.viewmodels


import androidx.databinding.Observable
import androidx.databinding.PropertyChangeRegistry
import androidx.lifecycle.ViewModel


open class ObservableViewModel : ViewModel(), Observable {

    @Transient
    private var mCallbacks: PropertyChangeRegistry? = null

    @Synchronized
    override fun addOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback) {
        if (mCallbacks == null) {
            mCallbacks = PropertyChangeRegistry()
        }
        mCallbacks!!.add(callback)
    }

    @Synchronized
    override fun removeOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback) {
        if (mCallbacks != null) {
            mCallbacks!!.remove(callback)
        }
    }

    @Synchronized
    fun notifyChange() {
        if (mCallbacks != null) {
            mCallbacks!!.notifyCallbacks(this, 0, null)
//            mCallbacks!!.notifyChange(this, BR._all)
        }
    }

    fun notifyPropertyChanged(fieldId: Int) {
        if (mCallbacks != null) {
            mCallbacks!!.notifyCallbacks(this, fieldId, null)
        }
    }
}
