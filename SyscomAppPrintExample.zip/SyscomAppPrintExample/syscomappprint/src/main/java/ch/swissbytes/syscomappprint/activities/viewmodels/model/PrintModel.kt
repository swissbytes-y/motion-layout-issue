package ch.swissbytes.syscomappprint.activities.viewmodels.model

import android.bluetooth.BluetoothDevice
import java.util.*

class PrintModel: Observable() {

    companion object {
        val DEVICES = "devices"
        val REFRESHING = "refreshing"
        val SEARCH_CONNECTION = "search_connection"
    }

    var devices: MutableList<BluetoothDevice> = mutableListOf()
        set(value) {
            field = value
            setChangedAndNotify(PrintModel.DEVICES)
        }

    var refreshing: Boolean = false
        set(value) {
            field = value
            setChangedAndNotify(PrintModel.REFRESHING)
        }

    var searchBluetoothConnection: Boolean = false
        set(value) {
            field = value
            setChangedAndNotify(PrintModel.SEARCH_CONNECTION)
        }

    private fun setChangedAndNotify(field: String) {
        setChanged()
        notifyObservers(field)
    }

}