package ch.swissbytes.syscomappprint.zebra;

/**
 * Created by Jorge on 04/11/2015.
 */
public interface ZebraFont {

    /**
     * Get the number of the font E.g. 0 or 7
     *
     * @return int
     */

    public int getNumber();

    /**
     * Get the size of the font
     *
     * @return int
     */
    public int getSize();

    /**
     * Get the width of the font in dots. 8 dots = 1 mm
     *
     * @return with in dots
     */
    public double getWidth();

    /**
     * Get the height of the font in dots. 8 dots = 1 mm
     *
     * @return height in dots
     */
    public double getHeight();
}
