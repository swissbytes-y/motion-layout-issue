package ch.swissbytes.syscomappprint.printers

import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import android.util.Log
import ch.swissbytes.syscomappbase.extensions.toFormattedString
import ch.swissbytes.syscomappprint.utils.ProdLine
import ch.swissbytes.syscomappprint.utils.SysPrinterInterface
import ch.swissbytes.syscomappprint.zebra.ZebraFontFactory
import ch.swissbytes.syscomappprint.zebra.ZebraFontType
import ch.swissbytes.syscomappprint.zebra.ZebraPrinter
import com.zebra.sdk.comm.ConnectionException
import com.zebra.sdk.printer.ZebraPrinterLanguageUnknownException
import kotlin.math.ceil

class ZebraPrinterImpl(override val device: BluetoothDevice) : SysPrinterInterface {

    private val TAG = this.javaClass.simpleName

    lateinit var zebraPrinter: ZebraPrinter
    private val pattern: String? = null

    override val isConnected: Boolean get() = zebraPrinter.isConnected

    override fun connect(listener: () -> Any, fail: () -> Any) {
        Thread {
            try {
                connect(ZebraPrinter(device.address))
                listener.invoke()
            } catch (e: java.lang.Exception) {
                fail.invoke()
            }
        }.start()
    }

    @Throws(ConnectionException::class)
    private fun connect(printer: ZebraPrinter) {
        zebraPrinter = printer
        zebraPrinter.open()
        zebraPrinter.setMediaFeedLength(0)
    }

    override fun printLn(vararg values: String) {
        values.forEach { zebraPrinter.writeAndGoToNextLine(it) }
    }

    override fun writeRightJustify(value: String) {
        val format = "%48s"
        zebraPrinter.write(String.format(format, value))
    }

    override fun write(value: String) {
        zebraPrinter.setX(8.toDouble())
        zebraPrinter.write(value)
    }

    override fun printProdLines(values: List<ProdLine>) {
        val ellipsize = 21.toDouble()
        val maxPatternTot = 10
        val maxPatternPName = 21
        val pattern = " %-5s%${maxPatternPName}s %8s %${maxPatternTot}s"
        printLn(String.format(pattern, "Qty", "Producto", "P.Unit.", "SubTot Bs"))
        zebraPrinter.writeAndGoToNextLine("---------------------------------------------", true)
        values.forEach { prod ->
            val pName = prod.name
            val numOfLines = if (pName.isEmpty()) 0 else ceil(pName.length / ellipsize).toInt() - 1
            (0..numOfLines).forEach { i ->
                val firstLine = i == 0
                val from = if (firstLine) i else i * ellipsize.toInt()
                var to = from + ellipsize.toInt() - 1
                if (to > pName.length) to = pName.length - 1
                printLn(
                    if (firstLine) String.format(
                        pattern,
                        prod.qty.toString(),
                        pName.substring(from..to),
                        "${prod.unitPrice.toFormattedString()} ",
                        prod.totalPrice.toFormattedString()
                    )
                    else String.format(pattern, "", pName.substring(from..to), "", "")
                )
            }
            print()
        }
    }

    override fun print() {
        try {
            zebraPrinter.print()
        } catch (e: Exception) {
        }
    }

    override fun printBoldLn(value: String) {
        zebraPrinter.setBold(2)
        printLn(value)
        setNormalMode()
    }

    override fun leftAndRight(left: String, right: String) {
        val width = 48
        val margin = width - left.length - 1
        val value = String.format("%s %" + margin + "s", left, right)
        printLn(value)
    }

    override fun printQrCode(qrCode: Bitmap) {
        try {
            zebraPrinter.printImage(qrCode, 140, 0, 300, 300)
        } catch (e: ConnectionException) {
        } catch (e: ZebraPrinterLanguageUnknownException) {
        }
        print()
    }

    override fun printLnRightJustify(value: String) {
        val format = "%48s"
        zebraPrinter.writeAndGoToNextLine(String.format(format, value))
        print()
    }

    override fun start() {}

    override fun stop() {}

    override fun printCentered(value: String) {
        val strLen = value.length
        val breakline = 40
        if (strLen > breakline) {
            val words = value.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            var count = 0
            var sb = StringBuilder()
            for (word in words) {
                count += word.length
                if (count > breakline) {
                    zebraPrinter.writeAndGoToNextLine(sb.toString(), true)
                    sb = StringBuilder()
                    sb.append(word)
                    count = 0
                } else {
                    sb.append(word)
                    sb.append(" ")
                }
            }
            zebraPrinter.writeAndGoToNextLine(sb.toString(), true)
        } else {
            zebraPrinter.writeAndGoToNextLine(value, true)
        }
        print()
    }

    override fun addLine(value: String) {
        zebraPrinter.goToTheNextLine()
    }

    override fun printTitle(value: String) {
        zebraPrinter.writeAndGoToNextLine(value, true)
        setNormalMode()
        print()
        addLine()
    }

    private fun setNormalMode() {
        zebraPrinter.setFont(ZebraFontFactory.getZebraFont(ZebraFontType.CONTENT_FONT))
        zebraPrinter.setBold(0)
        print()
    }

    override fun printSignature(image: Bitmap?, vararg values: String) {
        try {
            if (image != null) {
                zebraPrinter.printImage(image, 50, 0, 400, image.height / 2)
            } else {
                addSpace()
            }
            printDashedLine()
            for (i in values.indices) {
                addLine()
                printCentered(values[i])

            }
            addSpace()
        } catch (e: ConnectionException) {
            Log.e(TAG, "printImage", e)
        } catch (e: ZebraPrinterLanguageUnknownException) {
            Log.e(TAG, "printImage", e)
        }

        print()
    }

    override fun addLine() {
        zebraPrinter.goToTheNextLine()
    }

    private fun addSpace() {
        for (i in 0..1) {
            addLine()
        }
    }

    override fun setAlignModeCenter() {

    }

    override fun printDashedLine() {
        zebraPrinter.writeAndGoToNextLine("------------------------------------------", true)
        print()
    }
}