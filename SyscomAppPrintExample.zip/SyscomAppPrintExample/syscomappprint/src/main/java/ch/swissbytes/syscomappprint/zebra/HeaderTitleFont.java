package ch.swissbytes.syscomappprint.zebra;

/**
 * Created by Jorge on 04/11/2015.
 */
public class HeaderTitleFont implements ZebraFont {

    @Override
    public int getNumber() {
        return 0;
    }

    @Override
    public int getSize() {
        return 6;
    }

    @Override
    public double getWidth() {
        return 4;
    }

    @Override
    public double getHeight() {
        return 36;
    }

}
