package ch.swissbytes.syscomappprint.utils

import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import ch.swissbytes.syscomappprint.printers.ZebraPrinterImpl

enum class SysPrinterType {
    ZEBRA
}

data class ProdLine(val qty: Int, val name: String, val unitPrice: String, val totalPrice: String)

interface SysPrinterInterface {
    val device: BluetoothDevice
    val isConnected: Boolean
    fun connect(listener: () -> Any, fail: () -> Any)
    fun printLn(vararg values: String)
    fun leftAndRight(left: String, right: String)
    fun printBoldLn(value: String)
    fun printQrCode(qrCode: Bitmap)
    fun printLnRightJustify(value: String)
    fun write(value: String)
    fun printProdLines(values: List<ProdLine>)
    fun writeRightJustify(value: String)
    fun print()
    fun start()
    fun stop()
    fun printCentered(value: String)
    fun addLine(value: String)
    fun addLine()
    fun printTitle(value: String)
    fun printSignature(image: Bitmap?, vararg values: String)
    fun setAlignModeCenter()
    fun printDashedLine()

    companion object {
        fun getPrinter(device: BluetoothDevice, type: SysPrinterType): SysPrinterInterface =
                when (type) {
                    SysPrinterType.ZEBRA -> {
                        ZebraPrinterImpl(device)
                    }
                }
    }
}

