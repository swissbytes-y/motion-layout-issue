package ch.swissbytes.syscomappprint.zebra;

/**
 * Created by Jorge on 04/11/2015.
 */
public class TitleFont implements ZebraFont {

    @Override
    public int getNumber() {
        return 0;
    }

    @Override
    public int getSize() {
        return 3;
    }

    @Override
    public double getWidth() {
        return 2;
    }

    @Override
    public double getHeight() {
        return 18;
    }
}
