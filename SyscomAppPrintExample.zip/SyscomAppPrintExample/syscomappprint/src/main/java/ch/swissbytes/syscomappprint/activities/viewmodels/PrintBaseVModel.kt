package ch.swissbytes.syscomappprint.activities.viewmodels

import android.bluetooth.BluetoothDevice
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.Bindable
import androidx.databinding.library.baseAdapters.BR
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import ch.swissbytes.syscomappbase.extensions.showToast
import ch.swissbytes.syscomappprint.R
import ch.swissbytes.syscomappprint.activities.viewmodels.model.PrintModel
import ch.swissbytes.syscomappprint.pref.PrintPrefs
import ch.swissbytes.syscomappprint.utils.SearchBlueToothDeviceService
import ch.swissbytes.syscomappprint.utils.SysPrinterInterface
import ch.swissbytes.syscomappprint.utils.SysPrinterType
import java.util.*

class PrintBaseVModel(val activity: AppCompatActivity,
                      val model: PrintModel = PrintModel(),
                      private val onStartPrinting: (SysPrinterInterface) -> Unit) : Observer, ObservableViewModel() {

    private val TAG = this::class.java.simpleName
    private val mainLooper: Handler by lazy { Handler(Looper.getMainLooper()) }
    private val prefs: PrintPrefs by lazy { PrintPrefs.getInstance(activity) }

    val bluetoothDeviceService: SearchBlueToothDeviceService by lazy {
        SearchBlueToothDeviceService(activity)
    }

    private var printer: SysPrinterInterface? = null

    init {
        model.addObserver(this)

        bluetoothDeviceService.setBluetoothFoundListener(this::onBlueToothConnectionStart)
            .setNoBluetoothListener(this::onBlueToothConnectionStop)
            .setOnDefaultDeviceFoundListener(this::onDeviceClick)
            .setOnDeviceFoundListener(this::onDeviceFound)
            .setOnDiscoveryStart { refreshing = true}
            .setOnDiscoveryStop { refreshing = false }
            .scanDeviceAndNotifyIfDefaultFound()
    }

    fun onDestroy(){
        bluetoothDeviceService.onDestroy()
    }

    override fun update(o: Observable?, fieldChanged: Any?) {
        if (fieldChanged is String){
            when (fieldChanged){
                PrintModel.DEVICES -> notifyPropertyChanged(BR.devices)
                PrintModel.REFRESHING -> notifyPropertyChanged(BR.refreshing)
                PrintModel.SEARCH_CONNECTION -> notifyPropertyChanged(BR.searchConnection)
            }
        }
    }

    var showAdvice: Boolean = false @Bindable get() = prefs.showAdvice

    var refreshing: Boolean = false @Bindable get() = model.refreshing
        set(refreshing) {
            field = refreshing
            model.refreshing = refreshing
            notifyPropertyChanged(BR.refreshing)
        }

    var devices: MutableList<BluetoothDevice> = mutableListOf() @Bindable get() = model.devices
        set(value) {
            field = value
            model.devices = field
        }

    var searchConnection: Boolean = false @Bindable get() = model.searchBluetoothConnection
        set(searchConnection) {
            field = searchConnection
            model.searchBluetoothConnection = searchConnection
            notifyPropertyChanged(BR.searchConnection)
        }

    private fun onDeviceFound(d: BluetoothDevice) {
        devices.add(d)
        notifyPropertyChanged(BR.devices)
    }

    private fun onBlueToothConnectionStop() {
        activity.showToast(activity.getString(R.string.onBlueToothConnectionStop))
    }

    private fun onBlueToothConnectionStart() {
        activity.showToast(activity.getString(R.string.connection_start))
    }

    fun onBluetoothDeviceClick(): (Any) -> Unit = { device ->
        when (device) {
            is BluetoothDevice -> mainLooper.postDelayed({ onDeviceClick(device) }, 200)
        }
    }

    fun onAdviceClick() {
        activity.findViewById<View>(R.id.advice_container).visibility = View.GONE
        prefs.showAdvice = false
    }

    fun onRefreshListener(): SwipeRefreshLayout.OnRefreshListener = object: SwipeRefreshLayout.OnRefreshListener {
        override fun onRefresh() {
            if (bluetoothDeviceService.starDiscovering()) {
                model.refreshing = true
                mainLooper.postDelayed({ model.refreshing = false }, 10000);
            } else {
                model.refreshing = false
            }
        }
    }

    private fun onDeviceClick(device: BluetoothDevice) {
        if (samePrinterIsAlreadyConnected(device.address)) {
            startPrinting()
        } else {
            printer = SysPrinterInterface.getPrinter(device, SysPrinterType.ZEBRA)
            printer!!.connect({ onDeviceConnectionSucceed() }) { onDeviceConnectionFail() }
        }
    }

    private fun samePrinterIsAlreadyConnected(address: String): Boolean {
        return printer != null && printer!!.device.address == address && printer!!.isConnected
    }

    private fun onDeviceConnectionSucceed() {
        mainLooper.post {
            if (printer != null) {
                startPrinting()
            }
        }
    }

    private fun onDeviceConnectionFail() {
        activity.showToast(activity.getString(R.string.connection_fail))
    }

    private fun startPrinting(){
        printer?.let { onStartPrinting.invoke(it) }
    }

}