package ch.swissbytes.syscomappprintexample


import ch.swissbytes.syscomappprint.activities.BasePrintActivity
import ch.swissbytes.syscomappprint.utils.ProdLine
import ch.swissbytes.syscomappprint.utils.SysPrinterInterface


class PrintActivity : BasePrintActivity() {

    override fun onStartPrinting(printer: SysPrinterInterface) {
        printer.printProdLines(
            listOf(
                ProdLine(12, "23109481023", 12.toString(), 12.toString()),
                ProdLine(12, "23109481023984012394801293840918234091238409", 10.toString(), 120.toString()),
                ProdLine(12, "231094810239840 091238409", 1000.toString(), 12000.toString())
            )
        )
    }
}
